import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from scrapy.exceptions import CloseSpider
from mercado.items import MercadoItem

class MercadoSpider(CrawlSpider):
    name = 'mercado'
    item_count = 0
    allowed_domain = ['www.mercadolibre.com.mx']
    start_urls = ['https://listado.mercadolibre.com.mx/impresora#D[A:impresora]']

    rules ={
        #primera regla correponde a boton siguiente
        Rule(LinkExtractor(allow=(), restrict_xpaths=('//li[@class="andes-pagination__button andes-pagination__button--next"]/a'))),
        #la segunda regla correponde a link de cada producto
        Rule(LinkExtractor(allow=(), restrict_xpaths=('//div[@class="ui-search-item__group ui-search-item__group--title"]/a')),
             callback='parse_item', follow=False)
    }

    def parse_item(self, response):
        ml_item = MercadoItem()
        ml_item['titulo'] = response.xpath('normalize-space(//h1[@class="ui-pdp-title"]/text())').extract()
        ml_item['precio'] = response.xpath('normalize-space(//div[@class="ui-pdp-price mt-16 ui-pdp-price--size-large"]/div[1]/span)').extract()

        self.item_count += 1
        if self.item_count > 5:
            raise CloseSpider('item_exceeded')
        yield ml_item